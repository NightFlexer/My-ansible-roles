docker kill $(docker ps -aq)
sleep 5s
