<?php

    print phpinfo();
