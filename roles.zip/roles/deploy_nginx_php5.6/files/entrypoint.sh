#!/usr/bin/env bash
service nginx start
php-fpm
